const $=id=>document.getElementById(id),KEY='vtaper_pro_v1';
const defaults={weights:[{date:new Date().toLocaleDateString('pt-BR'),value:60}],meals:[],sessions:[],measures:[],draft:[]};
let data=(()=>{try{return {...defaults,...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch{return structuredClone(defaults)}})();
let deferred=null,timerSecs=90,timerId=null;
const routine=[['SEG','Pernas A'],['TER','Peito'],['QUA','Costas'],['QUI','Pernas B'],['SEX','Ombros + peito complementar'],['SÁB','Descanso'],['DOM','Descanso']];
const presets={
'Pernas A':['Leg press','Cadeira extensora','Mesa flexora','Panturrilha'],
'Peito':['Fly','Supino inclinado','Supino sentado','Supino deitado','Tríceps na polia'],
'Costas':['Barra fixa assistida','Puxada alta','Remada baixa','Rosca na polia','Rosca martelo'],
'Pernas B':['Agachamento goblet','Cadeira extensora','Cadeira flexora','Elevação pélvica','Panturrilha'],
'Ombros + peito complementar':['Elevação lateral','Desenvolvimento na máquina','Crucifixo inverso','Supino inclinado','Tríceps na polia']
};
function persist(){try{localStorage.setItem(KEY,JSON.stringify(data))}catch(e){toast('Não foi possível salvar: espaço do navegador indisponível. Exporte um backup.')}}
function fmt(n){return Number(n).toLocaleString('pt-BR',{maximumFractionDigits:1})}
function toast(s){const t=$('toast');t.textContent=s;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function currentWeight(){return data.weights.at(-1)?.value??60}
function render(){
 const w=currentWeight(),gain=Math.max(0,w-60),volume=data.sessions.reduce((a,s)=>a+(s.volume||0),0);
 $('heroWeight').innerHTML=fmt(w)+'<small>kg</small>';$('dashWeight').innerHTML=fmt(w)+' <small>kg</small>';$('goalBar').style.width=Math.min(100,gain/10*100)+'%';$('goalStatus').textContent=fmt(gain)+' kg conquistados';
 $('dashSessions').textContent=data.sessions.length;$('dashVolume').textContent=Math.round(volume).toLocaleString('pt-BR');$('today').textContent=new Date().toLocaleDateString('pt-BR',{day:'2-digit',month:'short',year:'numeric'});
 $('schedule').innerHTML=routine.map(([d,t])=>`<div class="schedule-row ${t==='Descanso'?'rest':''}"><b>${d}</b><span>${t}</span></div>`).join('');
 renderDraft();renderMeals();renderWeights();renderMeasures();renderSessions();persist();
}
function renderDraft(){
 $('exerciseCount').textContent=data.draft.length+' exercícios';
 $('exerciseList').className='exercise-list'+(data.draft.length?'':' empty');
 $('exerciseList').innerHTML=data.draft.length?data.draft.map((e,i)=>`<article class="exercise-card"><div class="exercise-head"><div><b>${esc(e.name)}</b><small>${esc(e.day)} • ${e.sets} séries • alvo ${esc(e.target)} • pausa ${e.rest}s</small></div><button class="remove" data-remove="${i}">×</button></div><div class="set-grid">${e.logs.map((s,j)=>`<div class="set-cell ${s.done?'done':''}"><span>SÉRIE ${j+1}</span><input aria-label="Repetições série ${j+1}" type="number" min="0" placeholder="reps" value="${s.reps||''}" data-log-reps="${i}:${j}"><input aria-label="Carga série ${j+1}" type="number" min="0" step=".5" placeholder="kg" value="${s.load??e.load??''}" data-log-load="${i}:${j}"><button class="btn ${s.done?'primary':'secondary'}" data-done="${i}:${j}">${s.done?'FEITA':'OK'}</button></div>`).join('')}</div></article>`).join(''):'Seu treino começa quando adicionar um exercício.';
}
function renderMeals(){const today=new Date().toLocaleDateString('pt-BR'),arr=data.meals.filter(m=>m.date===today);$('kcal').textContent=arr.reduce((a,m)=>a+m.kcal,0).toLocaleString('pt-BR');$('protein').innerHTML=arr.reduce((a,m)=>a+m.protein,0)+'<small>g</small>';$('mealList').className='history'+(arr.length?'':' empty');$('mealList').innerHTML=arr.length?arr.map(m=>`<div class="history-row"><div><b>${esc(m.name)}</b><small>${m.kcal} kcal • ${m.protein} g proteína</small></div><button class="remove" data-meal="${data.meals.indexOf(m)}">×</button></div>`).join(''):'Nenhuma refeição registrada hoje.'}
function renderWeights(){let a=data.weights.slice(-10);$('weightChart').className='chart'+(a.length?'':' empty');$('weightChart').innerHTML=a.length?a.map(x=>`<div class="chart-bar" style="height:${Math.max(12,Math.min(100,30+(x.value-50)*5))}%"><span>${fmt(x.value)}</span></div>`).join(''):'Adicione registros para visualizar sua evolução.';$('weightHistory').innerHTML=data.weights.slice().reverse().slice(0,6).map(x=>`<div class="history-row"><span>${x.date}</span><b>${fmt(x.value)} kg</b></div>`).join('')}
function renderMeasures(){$('measureHistory').innerHTML=data.measures.slice().reverse().slice(0,5).map(m=>`<div class="history-row"><span>${m.date}</span><b>${Object.entries(m.values).map(([k,v])=>k+' '+v+' cm').join(' • ')}</b></div>`).join('')}
function renderSessions(){$('sessionHistory').className='history'+(data.sessions.length?'':' empty');$('sessionHistory').innerHTML=data.sessions.slice().reverse().slice(0,8).map(s=>`<div class="history-row"><div><b>${esc(s.day)}</b><small>${s.date} • ${s.exercises} exercícios</small></div><b>${Math.round(s.volume)} kg</b></div>`).join('')||'Seus treinos concluídos aparecerão aqui.'}
document.querySelectorAll('.navbtn').forEach(b=>b.onclick=()=>{document.querySelectorAll('.navbtn,.page').forEach(x=>x.classList.remove('active'));b.classList.add('active');$(b.dataset.page).classList.add('active')});
$('daySelect').onchange=()=>{$('presetHint').textContent='Sugestão: '+presets[$('daySelect').value].join(' • ')};
$('loadPreset').onclick=()=>{const day=$('daySelect').value,exists=data.draft.some(x=>x.day===day);if(exists){toast('Esse treino já tem exercícios na sessão.');return}presets[day].forEach(name=>data.draft.push({name,day,sets:3,target:'8–12',load:0,rest:120,logs:Array.from({length:3},()=>({reps:'',load:'',done:false}))}));persist();renderDraft();toast('Exercícios sugeridos adicionados')};
$('addExercise').onclick=()=>{const name=$('exercise').value.trim();if(!name)return toast('Digite o nome do exercício');const sets=Math.max(1,Math.min(12,+$('setCount').value||3));data.draft.push({name,day:$('daySelect').value,sets,target:$('targetReps').value||'8–12',load:+$('load').value||0,rest:+$('rest').value||90,logs:Array.from({length:sets},()=>({reps:'',load:$('load').value||'',done:false}))});$('exercise').value='';persist();renderDraft();toast('Exercício adicionado')};
$('exerciseList').addEventListener('click',e=>{if(e.target.dataset.remove!==undefined){data.draft.splice(+e.target.dataset.remove,1);persist();renderDraft()}if(e.target.dataset.done){const [i,j]=e.target.dataset.done.split(':').map(Number);data.draft[i].logs[j].done=!data.draft[i].logs[j].done;persist();renderDraft()}});
$('exerciseList').addEventListener('change',e=>{for(const key of ['logReps','logLoad'])if(e.target.dataset[key]){const [i,j]=e.target.dataset[key].split(':').map(Number);data.draft[i].logs[j][key==='logReps'?'reps':'load']=e.target.value;persist()}});
$('completeWorkout').onclick=()=>{if(!data.draft.length)return toast('Adicione exercícios antes de concluir');const volume=data.draft.reduce((sum,e)=>sum+e.logs.reduce((v,s)=>v+(+s.reps||0)*(+s.load||0),0),0);data.sessions.push({date:new Date().toLocaleDateString('pt-BR'),day:$('daySelect').value,exercises:data.draft.length,volume,items:data.draft});data.draft=[];persist();render();toast('Treino concluído e salvo!')};
$('addMeal').onclick=()=>{const name=$('mealName').value.trim();if(!name)return toast('Informe a refeição');data.meals.push({name,kcal:+$('mealKcal').value||0,protein:+$('mealProtein').value||0,date:new Date().toLocaleDateString('pt-BR')});['mealName','mealKcal','mealProtein'].forEach(id=>$(id).value='');persist();renderMeals();toast('Refeição registrada')};
$('mealList').onclick=e=>{if(e.target.dataset.meal!==undefined){data.meals.splice(+e.target.dataset.meal,1);persist();renderMeals()}};
$('saveWeight').onclick=()=>{const v=+$('weightInput').value;if(!v||v<1)return toast('Informe um peso válido');data.weights.push({date:new Date().toLocaleDateString('pt-BR'),value:v});$('weightInput').value='';persist();render();toast('Peso salvo')};
$('saveMeasures').onclick=()=>{const vals={Cintura:$('waist').value,Peito:$('chest').value,Braço:$('arm').value,Coxa:$('thigh').value};Object.keys(vals).forEach(k=>{if(!vals[k])delete vals[k]});if(!Object.keys(vals).length)return toast('Preencha ao menos uma medida');data.measures.push({date:new Date().toLocaleDateString('pt-BR'),values:vals});persist();renderMeasures();toast('Medidas salvas')};
$('export').onclick=()=>download('v-taper-backup.json',JSON.stringify(data,null,2),'application/json');
function download(name,content,type){const a=document.createElement('a'),u=URL.createObjectURL(new Blob([content],{type}));a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)}
$('importFile').onchange=async e=>{try{const obj=JSON.parse(await e.target.files[0].text());if(!obj.weights||!obj.sessions)throw Error();data={...defaults,...obj};persist();render();toast('Backup importado')}catch{toast('Arquivo de backup inválido')}e.target.value=''};
$('resetData').onclick=()=>{if(confirm('Apagar todos os registros V-Taper deste navegador? Esta ação não pode ser desfeita.')){data=structuredClone(defaults);persist();render();toast('Dados apagados')}};
let promptEvent;window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();promptEvent=e;$('install').classList.remove('hidden')});$('install').onclick=async()=>{if(promptEvent){promptEvent.prompt();await promptEvent.userChoice;promptEvent=null}};
function showTimer(){$('timer').textContent=String(Math.floor(timerSecs/60)).padStart(2,'0')+':'+String(timerSecs%60).padStart(2,'0')}
$('timerStart').onclick=()=>{if(timerId){clearInterval(timerId);timerId=null;$('timerStart').textContent='Continuar';return}$('timerStart').textContent='Pausar';timerId=setInterval(()=>{timerSecs=Math.max(0,timerSecs-1);showTimer();if(!timerSecs){clearInterval(timerId);timerId=null;$('timerStart').textContent='Iniciar';toast('Descanso finalizado!');if(navigator.vibrate)navigator.vibrate([200,100,200])}},1000)};
$('timerReset').onclick=()=>{clearInterval(timerId);timerId=null;timerSecs=+$('rest').value||90;showTimer();$('timerStart').textContent='Iniciar'};
render();showTimer();$('presetHint').textContent='Sugestão: '+presets[$('daySelect').value].join(' • ');
