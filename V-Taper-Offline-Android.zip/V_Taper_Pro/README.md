# V-Taper Pro — aplicativo instalável e offline

Esta versão funciona como um aplicativo no Android: instala um ícone na tela inicial, abre em tela cheia e mantém os registros no próprio aparelho. Depois da primeira instalação/carregamento completo, treino, cronômetro, alimentação, peso, medidas e histórico funcionam sem internet.

## Instalar no Android
1. Hospede esta pasta em um endereço HTTPS (por exemplo, GitHub Pages, Netlify ou Vercel). A instalação PWA exige HTTPS.
2. No celular, abra o endereço no Chrome e aguarde carregar.
3. Toque em **Instalar** no cabeçalho ou no menu do Chrome → **Instalar app** / **Adicionar à tela inicial**.
4. Abra pelo novo ícone **V-Taper**. Depois de abrir uma vez com internet e o cache terminar, pode usar em modo avião.

## Importante sobre uso offline
- A primeira abertura precisa de internet para baixar e guardar os arquivos do app.
- Os dados ficam localmente no armazenamento do navegador/app (não há conta nem sincronização).
- Use **Exportar backup** regularmente para não perder os registros se limpar os dados do navegador ou trocar de celular.
- Não desinstale/limpe os dados antes de exportar o backup.

## Rotina configurada
Segunda: Pernas A; terça: Peito; quarta: Costas; quinta: Pernas B; sexta: Ombros + peito complementar; sábado e domingo: descanso.

## Sobre APK
Este pacote é um PWA instalável, que se comporta como app no Android e funciona offline. Ele ainda não é um arquivo APK nativo assinado. Para gerar APK é necessário empacotar/assinar com Android Studio ou serviço de build Android.
